package com.teststore.Utilities;

public class WebDriverUtilites extends Generic{
	
}
